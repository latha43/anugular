"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var list_1 = require("./list");
var search_1 = require("./search");
var delete_1 = require("./delete");
var addup_1 = require("./addup");
exports.routing = [
    { path: 'list', component: list_1.ListComponent },
    { path: 'search', component: search_1.SearchComponent },
    { path: 'delete', component: delete_1.DeleteComponent },
    { path: 'addup', component: addup_1.AddUpComponent }
];
//# sourceMappingURL=app.routing.js.map