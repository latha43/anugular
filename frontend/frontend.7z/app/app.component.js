"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var AppComponent = (function () {
    function AppComponent(formBuilder) {
        this.formBuilder = formBuilder;
        this.name = 'register';
        this.show = false;
        this.loginform = this.formBuilder.group({
            'EmpName': ['', forms_1.Validators.required],
            'pwd': ['', forms_1.Validators.required]
        });
        console.log(this.loginform);
    }
    AppComponent.prototype.onclick = function (u, p) {
        if (u == p && u != "") {
            this.status = 'Login successful';
            this.show = !this.show;
            console.log(status);
        }
        else {
            this.status = 'Login failed';
            console.log(status);
        }
    };
    AppComponent.prototype.onclick1 = function () {
        window.location.replace('/logout');
        this.show = !this.show;
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'app',
        template: "<div *ngIf=\"!show\">\n    <div class=image align=\"center\">\n    <h1><b>Welcome to UST Global</b> </h1>\n \n\n   <br><br><br>\n    <form [formGroup]=\"loginform\">\n           <input type=\"text\"  placeholder=\"enter your username\" formControlName=\"EmpName\"#user>\n            <control-messages [control]=\"loginform.controls.EmpName\"></control-messages>\n             <br><br>\n\t\t  <input type=\"password\"  placeholder=\"enter your password\" formControlName=\"pwd\" #pwd>\n\t\t   <control-messages [control]=\"loginform.controls.pwd\"></control-messages>\n\t\t\t  <br><br><br>\n\t\t\t<button (click)=\"onclick(user.value,pwd.value)\"  [disabled]=\"!loginform.valid\" class=\"button5\">Login</button>\n\t\t\t</form>\n\t\t\t<h2>{{status}}</h2>\n    </div>\n    \n    </div>\n      \n        <div align=\"center\" *ngIf=\"show\">\n        <h1><b><marquee> Welcome User </marquee></b></h1>\n          \t<button (click)=\"onclick1()\" class=\"button5\" id=\"pos\">Logout</button>\n        <Staff-list></Staff-list>\n        </div>\n        ",
        styles: ["h1{color:red;}"]
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map