"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var test_service_1 = require("./test.service");
var core_1 = require("@angular/core");
var AddUpComponent = (function () {
    function AddUpComponent(_employeeService) {
        this._employeeService = _employeeService;
    }
    AddUpComponent.prototype.addEmployee = function (id, name, Dept, ph_no) {
        var _this = this;
        this._employeeService.addEmp(id, name, Dept, ph_no)
            .subscribe(function (resEmployeeData) { return _this.status1 = (resEmployeeData); });
    };
    AddUpComponent.prototype.Edit = function (id, name, Dept, ph_no) {
        var _this = this;
        this._employeeService.edit(id, name, Dept, ph_no).subscribe(function (resEmployeeData) { return _this.status1 = (resEmployeeData); });
    };
    return AddUpComponent;
}());
AddUpComponent = __decorate([
    core_1.Component({
        selector: 'add',
        template: "<h2>Staff Details </h2><br>\n  Staff ID <input type=\"text\" #id>\n  Name <input type=\"text\" #name>\n  Department <input type=\"text\" #Dept>\n  Phone_no <input type=\"text\" #ph_no>\n <br><br>\n<p>Status:{{status1}}</p><br>\n<button (click)=\"addEmployee(id.value,name.value,Dept.value,ph_no.value)\">INSERT</button>\n<button (click)=\"Edit(id.value,name.value,Dept.value,ph_no.value)\">EDIT</button>\n                   ",
        providers: [test_service_1.EmployeeService]
    }),
    __metadata("design:paramtypes", [test_service_1.EmployeeService])
], AddUpComponent);
exports.AddUpComponent = AddUpComponent;
//# sourceMappingURL=addup.js.map