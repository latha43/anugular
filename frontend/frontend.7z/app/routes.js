"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
router_1.RouterModule.forRoot([
    {
        path: 'search', component: SearchComponent,
        path: 'list', component: ListComponent,
        path: 'addup', component: AddUpComponent,
        path: 'delete', component: DeleteComponent
    }
]);
//# sourceMappingURL=routes.js.map